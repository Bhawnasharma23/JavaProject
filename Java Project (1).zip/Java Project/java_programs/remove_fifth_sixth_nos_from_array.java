package java_programs;

import java.util.Arrays;

public class remove_fifth_sixth_nos_from_array
{

	public static void main(String[] args) 
	{
		double[] array = {1, 3, 4, 5, 6, 7.9, 8, 9.9, 10};

        if (array.length >= 6)
        {
            double[] newArray = new double[array.length - 2];
            
            System.arraycopy(array, 0, newArray, 0, 4);
            System.arraycopy(array, 6, newArray, 4, array.length - 6);
            System.out.println("Original array: " + Arrays.toString(array));
            System.out.println("Array after deletion: " + Arrays.toString(newArray));
        } 
        else
        {
            System.out.println("Array length is too short to perform deletion.");
        }
    }

}
