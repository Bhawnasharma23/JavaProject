package core_java_programs;

public class encapsulation1 
{
    private String Name;
	public String getName() 
	{
		return Name;
	}
	public void setName(String Name)
	{
		this.Name = Name;
	}
}
