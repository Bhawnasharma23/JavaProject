package core_java_programs;

public class methodoverriding2_extends_methodoverriding1 
{

	int speedlimit = 120;

	void abc() 
	{
		System.out.println("extended class ");
	}

	void cde() 
	{
		System.out.println("speed limit");
		System.out.println("super.speedlimit");
	}

	public static void main(String[] args) 
	{
		methodoverriding1 rr = new methodoverriding1(); 
		System.out.println("rr.speedlimit");
		rr.abc();
		System.out.println("-------dynamic method dispatch----------");

		methodoverriding2 re = new methodoverriding2();
		System.out.println("re.speedlimit");
		re.cde();
	}

}

