package core_java_programs;

	class C
	{
	   public void disp()
	   {
		System.out.println("C");
	   }
	}

	class A extends C
	{
	   public void disp()
	   {
		System.out.println("A");
	   }
	}

	class B extends C
	{
	   public void disp()
	   {
		System.out.println("B");
	   }
		
	}

	class hybrid_inheritance extends A
	{
	   public void disp()
	   {
		System.out.println("D");
	   }
	   public static void main(String args[])
	   {

		hybrid_inheritance obj = new hybrid_inheritance();
		obj.disp();
	   }
}
