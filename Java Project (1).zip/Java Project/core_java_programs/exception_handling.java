package core_java_programs;

public class exception_handling {

	public static void main(String[] args) 
	{
         try 
			{
			    int a[] = new int[5];
				a[5] = 30 / 0; 
				a[3] = 30 / 3;
				System.out.println("try block is executed");
			} 
			catch (ArithmeticException e) 
			{
				System.out.println("task 1 is completed");
			} 
			catch (ArrayIndexOutOfBoundsException e)
			{
				System.out.println("task 2 is completed");
			} 
			catch (Exception e)
			{
				System.out.println("common task is completed");
			} 
			finally 
			{
				System.out.println("this code always be excuted");
			}
			System.out.println("rest of the code");

	}

}
