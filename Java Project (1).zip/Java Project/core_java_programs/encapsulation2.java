package core_java_programs;

public class encapsulation2 
{

	public static void main(String[] args) 
	{
	encapsulation1 en= new encapsulation1();
		
		en.setName("Anjali");
		System.out.println(en.getName());
	}
}